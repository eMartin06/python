import turtle #Lehetővé teszi a teknőc használatát



ablak=turtle.Screen() #Hozz létre egy játszóteret a teknőcnek
ablak.bgcolor("lightgreen")
ablak.title("Hello, 10e!")
Eszti = turtle.Turtle()
Eszti.color("blue")
Nori=turtle.Turtle() #Hozz létre egy teknőcöt Nori néven

Nori.forward(50) # Nori menjen 50 egységet előre!
Nori.left(90) # Nori forduljon 90 fokot!
Nori.forward(30) #Rajzold meg a téglalap Második oldalát!
Nori.left(90)
Nori.forward(55)
Nori.left(90)
Nori.forward(30)
Nori.left(90)
Nori.forward(5)

ablak.mainloop() #Várj, amíg a felhasználó bezárja az ablakot






 