#!/usr/bin/env python 3

ellenség= input('Ki volt a piroska nevű szuperhős főellensége? ')
if ellenség == 'farkas' or ellenség== 'Farkas':
    print("Okos vagy.")
    print("Nem is kicsit.")
if ellenség == "ordas":
    pass
    #print("Hááát..nem..")
else:
    print("Hááát....")
    print("Nem.")
print ("Legközelebb a hét törpét kérdezem - visszafele!")