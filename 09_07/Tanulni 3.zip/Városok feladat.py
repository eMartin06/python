
Városok =['Miskolc', 'Párizs', 'Dublin', 'Lajosmizse']

for index, város in enumerate(Városok): #enumerate: számozd be!
  pass  # print(index, város)

# while len(Városok)> 0:
#     print('várasók:', ', '.join(város))

for város in Városok:
    print(város, 'egy város európában.')

for index, város in Városok:
    print(város, 'egy város európában.')