fővárosok = ['Párizs','Bécs', 'Róma','Prága']

for index in range(len(fővárosok)):
    print(index,fővárosok[index])