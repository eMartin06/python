számláló =0
összeg= 0
'''
while számláló <100:
    számláló+=1
    összeg=összeg+számláló
print('Összesen:', összeg)
'''

for i in range(1,101):
    összeg= összeg+i
    számláló = számláló+ 1
print(összeg)