
összeg = None
while összeg != 4:
    összeg = input('Mennyi kétszer kettő? ')
    összeg= int(összeg)
print('Annyi')